package worker

import (
	"log"
	"smart-mcq/internal/database"
	"time"
)

// StartRankingWorker starts a background worker that calculates rankings every 10 seconds
func StartRankingWorker() {
	ticker := time.NewTicker(10 * time.Second)

	log.Println("✅ Ranking worker started (runs every 10 seconds)")

	go func() {
		// Run immediately on start
		calculateRankings()

		// Then run every 10 seconds
		for range ticker.C {
			calculateRankings()
		}
	}()
}

func calculateRankings() {
	log.Println("🔄 Calculating rankings...")

	err := database.CalculateRankings()
	if err != nil {
		log.Printf("❌ Error calculating rankings: %v\n", err)
		return
	}

	log.Println("✅ Rankings calculated successfully")
}
