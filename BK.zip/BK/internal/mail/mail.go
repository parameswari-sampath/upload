package mail

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/joho/godotenv"
)

type EmailAddress struct {
	Address string `json:"address"`
	Name    string `json:"name,omitempty"`
}

type To struct {
	EmailAddress EmailAddress `json:"email_address"`
}

type EmailRequest struct {
	From     EmailAddress `json:"from"`
	To       []To         `json:"to"`
	Subject  string       `json:"subject"`
	HTMLBody string       `json:"htmlbody"`
}

func SendMail(toEmail, toName, subject, body string) error {
	// load env (in main.go we'll load once, but safe here too)
	_ = godotenv.Load()

	apiURL := os.Getenv("ZEPTO_API_URL")
	apiKey := os.Getenv("ZEPTO_API_KEY")
	fromEmail := os.Getenv("ZEPTO_FROM")

	// build request body
	reqBody := EmailRequest{
		From:     EmailAddress{Address: fromEmail},
		To:       []To{{EmailAddress: EmailAddress{Address: toEmail, Name: toName}}},
		Subject:  subject,
		HTMLBody: body,
	}

	jsonData, _ := json.Marshal(reqBody)

	// build HTTP request
	req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(jsonData))
	if err != nil {
		return err
	}

	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", apiKey)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// Accept any 2xx status code as success
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("failed to send mail, status: %s", resp.Status)
	}

	return nil
}

// SendTestInvite sends test invitation email to student
func SendTestInvite(toEmail, toName, inviteToken string) error {
	_ = godotenv.Load()

	frontendURL := os.Getenv("FRONTEND_URL")
	if frontendURL == "" {
		frontendURL = "http://localhost:3000"
	}

	testLink := fmt.Sprintf("%s/test?token=%s", frontendURL, inviteToken)
	startTime := os.Getenv("TEST_START_TIME")
	if startTime == "" {
		startTime = "11:00:00"
	}

	subject := "Your Test Invitation - Programming Assessment"
	body := fmt.Sprintf(`
		<!DOCTYPE html>
		<html>
		<head>
			<style>
				body { font-family: Arial, sans-serif; line-height: 1.6; color: #000000; background-color: #ffffff; }
				.container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff; }
				.header { background-color: #4CAF50; color: #ffffff; padding: 20px; text-align: center; }
				.content { padding: 20px; background-color: #ffffff; color: #000000; }
				.button { display: inline-block; padding: 12px 24px; background-color: #4CAF50; color: #ffffff !important; text-decoration: none; border-radius: 4px; margin: 20px 0; }
				.info { background-color: #e3f2fd; padding: 15px; border-left: 4px solid #2196F3; margin: 20px 0; color: #000000; }
				.footer { text-align: center; padding: 20px; color: #666666; font-size: 12px; background-color: #f5f5f5; }
				p, li, strong { color: #000000; }
				a { color: #2196F3; }
			</style>
		</head>
		<body>
			<div class="container">
				<div class="header">
					<h1 style="color: #ffffff;">Test Invitation</h1>
				</div>
				<div class="content">
					<p>Dear <strong>%s</strong>,</p>
					<p>You have been invited to take the <strong>Programming Assessment</strong>.</p>

					<div class="info">
						<strong>Test Details:</strong><br>
						⏰ Start Time: <strong>%s</strong><br>
						⏱️ Duration: <strong>4 minutes</strong><br>
						📝 Sections: <strong>4 sections (1 minute each)</strong><br>
						❓ Questions: <strong>20 MCQ questions</strong>
					</div>

					<p><strong>Important Instructions:</strong></p>
					<ul>
						<li>Click the button below to access your test</li>
						<li>The test will only be available at the scheduled start time</li>
						<li>You can only take the test once</li>
						<li>Make sure you have a stable internet connection</li>
						<li>Complete all sections within the time limit</li>
					</ul>

					<div style="text-align: center;">
						<a href="%s" class="button" style="color: #ffffff;">Start Test</a>
					</div>

					<p style="font-size: 12px; color: #666666;">Or copy this link: <a href="%s" style="color: #2196F3;">%s</a></p>
				</div>
				<div class="footer">
					<p>Good luck with your test!</p>
					<p>This is an automated email. Please do not reply.</p>
				</div>
			</div>
		</body>
		</html>
	`, toName, startTime, testLink, testLink, testLink)

	return SendMail(toEmail, toName, subject, body)
}
