package database

import (
	"context"
	"fmt"
	"log"
)

// DropAllTables drops all tables in the correct order (respecting foreign keys)
func DropAllTables() error {
	tables := []string{
		"test_responses",
		"section_transitions",
		"test_sessions",
		"results",
		"students",
		"tests",
	}

	log.Println("🗑️  Dropping all tables...")

	for _, table := range tables {
		query := fmt.Sprintf("DROP TABLE IF EXISTS %s CASCADE;", table)
		_, err := DB.Exec(context.Background(), query)
		if err != nil {
			return fmt.Errorf("failed to drop table %s: %w", table, err)
		}
		log.Printf("   Dropped table: %s", table)
	}

	log.Println("✅ All tables dropped successfully")
	return nil
}

// ResetDatabase drops all tables and recreates them
func ResetDatabase() error {
	// Drop all tables
	err := DropAllTables()
	if err != nil {
		return err
	}

	// Recreate tables by running migrations
	log.Println("🔄 Recreating tables...")
	Migrate()

	return nil
}
