package database

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"smart-mcq/internal/mail"
)

// Student struct
type Student struct {
	ID          int
	Name        string
	Email       string
	InviteToken string
}

// Generate random token
func generateToken() string {
	b := make([]byte, 16) // 16 bytes = 32 hex chars
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

// Save student with token (without sending email)
func AddStudent(name, email string) error {
	// Check if student already exists
	var count int
	checkQuery := `SELECT COUNT(*) FROM students WHERE email = $1`
	err := DB.QueryRow(context.Background(), checkQuery, email).Scan(&count)
	if err != nil {
		return fmt.Errorf("failed to check existing student: %w", err)
	}

	if count > 0 {
		return fmt.Errorf("student with email %s already exists", email)
	}

	// Insert new student
	token := generateToken()
	query := `
	INSERT INTO students (name, email, invite_token)
	VALUES ($1, $2, $3)
	RETURNING invite_token
	`

	var returnedToken string
	err = DB.QueryRow(context.Background(), query, name, email, token).Scan(&returnedToken)
	if err != nil {
		return fmt.Errorf("failed to insert student: %w", err)
	}

	return nil
}

// Send invite email to student
func SendInviteEmail(email string) error {
	var student Student
	query := `SELECT id, name, email, invite_token FROM students WHERE email = $1`

	err := DB.QueryRow(context.Background(), query, email).Scan(
		&student.ID,
		&student.Name,
		&student.Email,
		&student.InviteToken,
	)

	if err != nil {
		return fmt.Errorf("student not found")
	}

	// Send test invite email
	err = mail.SendTestInvite(student.Email, student.Name, student.InviteToken)
	if err != nil {
		return fmt.Errorf("failed to send email: %w", err)
	}

	return nil
}

// Get all students
func GetAllStudents() ([]Student, error) {
	query := `SELECT id, name, email, invite_token FROM students ORDER BY id`
	rows, err := DB.Query(context.Background(), query)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch students: %w", err)
	}
	defer rows.Close()

	var students []Student
	for rows.Next() {
		var student Student
		err := rows.Scan(&student.ID, &student.Name, &student.Email, &student.InviteToken)
		if err != nil {
			continue
		}
		students = append(students, student)
	}

	return students, nil
}

// Send invite emails to all students
func SendInviteEmailToAll() (int, int, []string, error) {
	students, err := GetAllStudents()
	if err != nil {
		return 0, 0, nil, err
	}

	successCount := 0
	failCount := 0
	var errors []string

	for _, student := range students {
		err := mail.SendTestInvite(student.Email, student.Name, student.InviteToken)
		if err != nil {
			failCount++
			errors = append(errors, fmt.Sprintf("%s (%s): %v", student.Name, student.Email, err))
			continue
		}
		successCount++
	}

	return successCount, failCount, errors, nil
}

// Bulk add students (for Excel upload)
func BulkAddStudents(students []struct {
	Name  string `json:"name"`
	Email string `json:"email"`
}) (int, int, []string, error) {
	successCount := 0
	skipCount := 0
	var errors []string

	for i, student := range students {
		// Skip if empty
		if student.Name == "" || student.Email == "" {
			skipCount++
			continue
		}

		// Check if already exists
		var count int
		checkQuery := `SELECT COUNT(*) FROM students WHERE email = $1`
		err := DB.QueryRow(context.Background(), checkQuery, student.Email).Scan(&count)
		if err != nil {
			errors = append(errors, fmt.Sprintf("Row %d: Failed to check email %s", i+1, student.Email))
			continue
		}

		if count > 0 {
			skipCount++
			continue
		}

		// Insert student
		token := generateToken()
		query := `INSERT INTO students (name, email, invite_token) VALUES ($1, $2, $3)`
		_, err = DB.Exec(context.Background(), query, student.Name, student.Email, token)
		if err != nil {
			errors = append(errors, fmt.Sprintf("Row %d: Failed to add %s - %v", i+1, student.Email, err))
			continue
		}

		successCount++
	}

	return successCount, skipCount, errors, nil
}

// Validate token and get student info
func ValidateInviteToken(token string) (*Student, error) {
	var student Student
	query := `SELECT id, name, email, invite_token FROM students WHERE invite_token = $1`

	err := DB.QueryRow(context.Background(), query, token).Scan(
		&student.ID,
		&student.Name,
		&student.Email,
		&student.InviteToken,
	)

	if err != nil {
		return nil, fmt.Errorf("invalid token")
	}

	return &student, nil
}
