package database

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"
)

// Test data structures
type Option struct {
	OptionID string `json:"option_id"`
	Text     string `json:"text"`
}

type Question struct {
	QuestionID    int      `json:"question_id"`
	QuestionText  string   `json:"question_text"`
	Options       []Option `json:"options"`
	CorrectAnswer string   `json:"correct_answer"`
}

type Section struct {
	SectionID       int        `json:"section_id"`
	SectionName     string     `json:"section_name"`
	DurationMinutes int        `json:"duration_minutes"`
	Questions       []Question `json:"questions"`
}

type Test struct {
	TestID               string    `json:"test_id"`
	TestName             string    `json:"test_name"`
	TotalDurationMinutes int       `json:"total_duration_minutes"`
	Sections             []Section `json:"sections"`
}

// Response structure for frontend
type TestResponse struct {
	TestID               string    `json:"test_id"`
	TestName             string    `json:"test_name"`
	StartTime            string    `json:"start_time"`
	TotalDurationMinutes int       `json:"total_duration_minutes"`
	Sections             []Section `json:"sections"`
}

// Student response structure
type StudentResponse struct {
	StudentID      int    `json:"student_id"`
	QuestionID     int    `json:"question_id"`
	SectionID      int    `json:"section_id"`
	SelectedOption string `json:"selected_option"`
}

// Load test from JSON file
func LoadTestFromJSON(filepath string) (*Test, error) {
	data, err := os.ReadFile(filepath)
	if err != nil {
		return nil, fmt.Errorf("failed to read test file: %w", err)
	}

	var test Test
	err = json.Unmarshal(data, &test)
	if err != nil {
		return nil, fmt.Errorf("failed to parse test JSON: %w", err)
	}

	return &test, nil
}

// Get test data with start time from env
func GetTestData() (*TestResponse, error) {
	test, err := LoadTestFromJSON("test_questions.json")
	if err != nil {
		return nil, err
	}

	startTime := os.Getenv("TEST_START_TIME")
	if startTime == "" {
		startTime = "11:00:00"
	}

	return &TestResponse{
		TestID:               test.TestID,
		TestName:             test.TestName,
		StartTime:            startTime,
		TotalDurationMinutes: test.TotalDurationMinutes,
		Sections:             test.Sections,
	}, nil
}

// Check if student has already attended the test
func HasStudentAttended(studentID int) (bool, error) {
	var count int
	query := `SELECT COUNT(*) FROM test_sessions WHERE student_id = $1`
	err := DB.QueryRow(context.Background(), query, studentID).Scan(&count)
	if err != nil {
		return false, fmt.Errorf("failed to check session: %w", err)
	}
	return count > 0, nil
}

// Start a new test session for student
func StartTestSession(studentID int) error {
	attended, err := HasStudentAttended(studentID)
	if err != nil {
		return err
	}
	if attended {
		return fmt.Errorf("student has already attended the test")
	}

	query := `INSERT INTO test_sessions (student_id) VALUES ($1)`
	_, err = DB.Exec(context.Background(), query, studentID)
	if err != nil {
		return fmt.Errorf("failed to start session: %w", err)
	}

	return nil
}

// Complete test session
func CompleteTestSession(studentID int) error {
	query := `UPDATE test_sessions SET completed_at = NOW(), is_active = FALSE WHERE student_id = $1`
	_, err := DB.Exec(context.Background(), query, studentID)
	if err != nil {
		return fmt.Errorf("failed to complete session: %w", err)
	}
	return nil
}

// Check if test time has expired
func IsTestExpired() (bool, error) {
	startTimeStr := os.Getenv("TEST_START_TIME")
	if startTimeStr == "" {
		startTimeStr = "11:00:00"
	}

	durationStr := os.Getenv("TEST_TOTAL_DURATION_MINUTES")
	duration := 4 // default
	if durationStr != "" {
		if d, err := strconv.Atoi(durationStr); err == nil {
			duration = d
		}
	}

	// Parse today's date with start time
	now := time.Now()
	todayStartTime := fmt.Sprintf("%s %s", now.Format("2006-01-02"), startTimeStr)
	testStart, err := time.Parse("2006-01-02 15:04:05", todayStartTime)
	if err != nil {
		return false, fmt.Errorf("failed to parse test start time: %w", err)
	}

	testEnd := testStart.Add(time.Duration(duration) * time.Minute)

	return now.After(testEnd), nil
}

// Save student response to database
func SaveStudentResponse(response StudentResponse) error {
	// Check if test time has expired
	expired, err := IsTestExpired()
	if err != nil {
		return err
	}
	if expired {
		return fmt.Errorf("test time has expired")
	}

	query := `
		INSERT INTO test_responses (student_id, question_id, section_id, selected_option)
		VALUES ($1, $2, $3, $4)
		ON CONFLICT (student_id, question_id)
		DO UPDATE SET selected_option = EXCLUDED.selected_option, answered_at = NOW()
	`

	_, err = DB.Exec(context.Background(), query,
		response.StudentID,
		response.QuestionID,
		response.SectionID,
		response.SelectedOption,
	)

	if err != nil {
		return fmt.Errorf("failed to save response: %w", err)
	}

	return nil
}

// Get all responses for a student
func GetStudentResponses(studentID int) ([]StudentResponse, error) {
	query := `
		SELECT student_id, question_id, section_id, selected_option
		FROM test_responses
		WHERE student_id = $1
		ORDER BY section_id, question_id
	`

	rows, err := DB.Query(context.Background(), query, studentID)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch responses: %w", err)
	}
	defer rows.Close()

	var responses []StudentResponse
	for rows.Next() {
		var resp StudentResponse
		err := rows.Scan(&resp.StudentID, &resp.QuestionID, &resp.SectionID, &resp.SelectedOption)
		if err != nil {
			return nil, fmt.Errorf("failed to scan response: %w", err)
		}
		responses = append(responses, resp)
	}

	return responses, nil
}
