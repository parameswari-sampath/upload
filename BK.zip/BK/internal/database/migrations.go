package database

import (
	"context"
	"log"
)

func Migrate() {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS students (
			id SERIAL PRIMARY KEY,
			name VARCHAR(100) NOT NULL,
			email VARCHAR(150) NOT NULL UNIQUE,
			invite_token VARCHAR(255),
			clicked_at TIMESTAMP,
			test_token VARCHAR(255),
			started_at TIMESTAMP,
			submitted_at TIMESTAMP,
			created_at TIMESTAMP DEFAULT NOW()
		);`,
		`CREATE TABLE IF NOT EXISTS tests (
			id SERIAL PRIMARY KEY,
			title VARCHAR(255) NOT NULL,
			duration INT NOT NULL,
			start_time TIMESTAMP,
			end_time TIMESTAMP,
			meet_url VARCHAR(255),
			created_at TIMESTAMP DEFAULT NOW()
		);`,
		`CREATE TABLE IF NOT EXISTS results (
			id SERIAL PRIMARY KEY,
			student_id INT REFERENCES students(id) UNIQUE,
			test_id INT REFERENCES tests(id),
			answers JSONB,
			score INT,
			submitted_at TIMESTAMP,
			overall_score INT DEFAULT 0,
			overall_time_seconds INT DEFAULT 0,
			section_scores JSONB,
			section_times JSONB,
			overall_rank INT,
			section_ranks JSONB,
			last_calculated_at TIMESTAMP,
			created_at TIMESTAMP DEFAULT NOW()
		);`,
		`CREATE TABLE IF NOT EXISTS test_responses (
			id SERIAL PRIMARY KEY,
			student_id INT REFERENCES students(id),
			question_id INT NOT NULL,
			section_id INT NOT NULL,
			selected_option VARCHAR(1) NOT NULL,
			answered_at TIMESTAMP DEFAULT NOW(),
			UNIQUE(student_id, question_id)
		);`,
		`CREATE TABLE IF NOT EXISTS test_sessions (
			id SERIAL PRIMARY KEY,
			student_id INT REFERENCES students(id) UNIQUE,
			started_at TIMESTAMP DEFAULT NOW(),
			completed_at TIMESTAMP,
			is_active BOOLEAN DEFAULT TRUE
		);`,
		`CREATE TABLE IF NOT EXISTS section_transitions (
			id SERIAL PRIMARY KEY,
			student_id INT REFERENCES students(id),
			section_id INT NOT NULL,
			entered_at TIMESTAMP DEFAULT NOW()
		);`,
	}

	for _, query := range queries {
		_, err := DB.Exec(context.Background(), query)
		if err != nil {
			log.Fatalf("Migration failed: %v", err)
		}
	}

	log.Println("✅ Database migrated successfully")
}
