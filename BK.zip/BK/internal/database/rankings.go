package database

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"time"
)

// Result structure with rankings
type Result struct {
	StudentID            int                `json:"student_id"`
	Name                 string             `json:"name"`
	OverallScore         int                `json:"overall_score"`
	OverallTimeSeconds   int                `json:"overall_time_seconds"`
	OverallRank          int                `json:"overall_rank"`
	SectionScores        map[string]int     `json:"section_scores"`
	SectionTimeSeconds   map[string]int     `json:"section_times"`
	SectionRanks         map[string]int     `json:"section_ranks"`
	LastCalculatedAt     time.Time          `json:"last_calculated_at"`
}

// Ranking entry for display
type RankingEntry struct {
	Rank        int    `json:"rank"`
	StudentID   int    `json:"student_id"`
	Name        string `json:"name"`
	Score       int    `json:"score"`
	TimeSeconds int    `json:"time_seconds"`
	TimeDisplay string `json:"time_display"`
}

// Section ranking entry
type SectionRankingEntry struct {
	Rank        int    `json:"rank"`
	StudentID   int    `json:"student_id"`
	Name        string `json:"name"`
	SectionScore int   `json:"section_score"`
	SectionTimeSeconds int `json:"section_time_seconds"`
	TimeDisplay string `json:"time_display"`
}

// Track section transition
func TrackSectionTransition(studentID, sectionID int) error {
	query := `INSERT INTO section_transitions (student_id, section_id) VALUES ($1, $2)`
	_, err := DB.Exec(context.Background(), query, studentID, sectionID)
	if err != nil {
		return fmt.Errorf("failed to track section transition: %w", err)
	}
	return nil
}

// Calculate score for a student
func CalculateStudentScore(studentID int) (*Result, error) {
	// Load test questions to get correct answers
	test, err := LoadTestFromJSON("test_questions.json")
	if err != nil {
		return nil, err
	}

	// Create map of correct answers
	correctAnswers := make(map[int]string)
	questionSections := make(map[int]int)
	for _, section := range test.Sections {
		for _, question := range section.Questions {
			correctAnswers[question.QuestionID] = question.CorrectAnswer
			questionSections[question.QuestionID] = section.SectionID
		}
	}

	// Get student responses
	responses, err := GetStudentResponses(studentID)
	if err != nil {
		return nil, err
	}

	// Calculate overall score and section scores
	overallScore := 0
	sectionScores := make(map[string]int)
	for sectionID := 1; sectionID <= 4; sectionID++ {
		sectionScores[fmt.Sprintf("%d", sectionID)] = 0
	}

	for _, resp := range responses {
		if correctAnswers[resp.QuestionID] == resp.SelectedOption {
			overallScore++
			sectionKey := fmt.Sprintf("%d", resp.SectionID)
			sectionScores[sectionKey]++
		}
	}

	// Get overall time from test_sessions
	var startedAt, completedAt *time.Time
	sessionQuery := `SELECT started_at, completed_at FROM test_sessions WHERE student_id = $1`
	err = DB.QueryRow(context.Background(), sessionQuery, studentID).Scan(&startedAt, &completedAt)
	if err != nil {
		return nil, fmt.Errorf("failed to get session time: %w", err)
	}

	overallTimeSeconds := 0
	if startedAt != nil && completedAt != nil {
		overallTimeSeconds = int(completedAt.Sub(*startedAt).Seconds())
	}

	// Calculate section times from section_transitions
	sectionTimes := make(map[string]int)
	transQuery := `
		SELECT section_id, entered_at
		FROM section_transitions
		WHERE student_id = $1
		ORDER BY section_id, entered_at
	`
	rows, err := DB.Query(context.Background(), transQuery, studentID)
	if err == nil {
		defer rows.Close()

		var transitions []struct {
			sectionID int
			enteredAt time.Time
		}

		for rows.Next() {
			var t struct {
				sectionID int
				enteredAt time.Time
			}
			rows.Scan(&t.sectionID, &t.enteredAt)
			transitions = append(transitions, t)
		}

		// Calculate time spent in each section
		for i := 0; i < len(transitions); i++ {
			sectionKey := fmt.Sprintf("%d", transitions[i].sectionID)
			var endTime time.Time

			if i+1 < len(transitions) {
				// Next section start is this section's end
				endTime = transitions[i+1].enteredAt
			} else if completedAt != nil {
				// Last section ends at test completion
				endTime = *completedAt
			} else {
				endTime = time.Now()
			}

			sectionTimes[sectionKey] = int(endTime.Sub(transitions[i].enteredAt).Seconds())
		}
	}

	// Fill missing section times with 0
	for sectionID := 1; sectionID <= 4; sectionID++ {
		sectionKey := fmt.Sprintf("%d", sectionID)
		if _, exists := sectionTimes[sectionKey]; !exists {
			sectionTimes[sectionKey] = 0
		}
	}

	result := &Result{
		StudentID:          studentID,
		OverallScore:       overallScore,
		OverallTimeSeconds: overallTimeSeconds,
		SectionScores:      sectionScores,
		SectionTimeSeconds: sectionTimes,
		LastCalculatedAt:   time.Now(),
	}

	return result, nil
}

// Save result to database
func SaveResult(result *Result) error {
	sectionScoresJSON, _ := json.Marshal(result.SectionScores)
	sectionTimesJSON, _ := json.Marshal(result.SectionTimeSeconds)
	sectionRanksJSON, _ := json.Marshal(result.SectionRanks)

	query := `
		INSERT INTO results (
			student_id, overall_score, overall_time_seconds,
			section_scores, section_times, overall_rank, section_ranks, last_calculated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
		ON CONFLICT (student_id)
		DO UPDATE SET
			overall_score = EXCLUDED.overall_score,
			overall_time_seconds = EXCLUDED.overall_time_seconds,
			section_scores = EXCLUDED.section_scores,
			section_times = EXCLUDED.section_times,
			overall_rank = EXCLUDED.overall_rank,
			section_ranks = EXCLUDED.section_ranks,
			last_calculated_at = EXCLUDED.last_calculated_at
	`

	_, err := DB.Exec(context.Background(), query,
		result.StudentID,
		result.OverallScore,
		result.OverallTimeSeconds,
		sectionScoresJSON,
		sectionTimesJSON,
		result.OverallRank,
		sectionRanksJSON,
		result.LastCalculatedAt,
	)

	if err != nil {
		return fmt.Errorf("failed to save result: %w", err)
	}

	return nil
}

// Calculate rankings for all students
func CalculateRankings() error {
	// Get all completed sessions
	query := `SELECT student_id FROM test_sessions WHERE completed_at IS NOT NULL`
	rows, err := DB.Query(context.Background(), query)
	if err != nil {
		return fmt.Errorf("failed to get completed sessions: %w", err)
	}
	defer rows.Close()

	var studentIDs []int
	for rows.Next() {
		var studentID int
		rows.Scan(&studentID)
		studentIDs = append(studentIDs, studentID)
	}

	// Calculate scores for all students
	var results []*Result
	for _, studentID := range studentIDs {
		result, err := CalculateStudentScore(studentID)
		if err != nil {
			continue // Skip on error
		}
		results = append(results, result)
	}

	// Calculate overall rankings
	sort.Slice(results, func(i, j int) bool {
		if results[i].OverallScore == results[j].OverallScore {
			return results[i].OverallTimeSeconds < results[j].OverallTimeSeconds
		}
		return results[i].OverallScore > results[j].OverallScore
	})

	// Assign overall ranks
	for i, result := range results {
		result.OverallRank = i + 1
		if result.SectionRanks == nil {
			result.SectionRanks = make(map[string]int)
		}
	}

	// Calculate section-wise rankings
	for sectionID := 1; sectionID <= 4; sectionID++ {
		sectionKey := fmt.Sprintf("%d", sectionID)

		// Sort by section score and time
		sortedResults := make([]*Result, len(results))
		copy(sortedResults, results)

		sort.Slice(sortedResults, func(i, j int) bool {
			scoreI := sortedResults[i].SectionScores[sectionKey]
			scoreJ := sortedResults[j].SectionScores[sectionKey]
			if scoreI == scoreJ {
				timeI := sortedResults[i].SectionTimeSeconds[sectionKey]
				timeJ := sortedResults[j].SectionTimeSeconds[sectionKey]
				return timeI < timeJ
			}
			return scoreI > scoreJ
		})

		// Assign section ranks
		for i, result := range sortedResults {
			for _, r := range results {
				if r.StudentID == result.StudentID {
					r.SectionRanks[sectionKey] = i + 1
					break
				}
			}
		}
	}

	// Save all results
	for _, result := range results {
		err := SaveResult(result)
		if err != nil {
			// Log error but continue
			fmt.Printf("Error saving result for student %d: %v\n", result.StudentID, err)
		}
	}

	return nil
}

// Get overall rankings (top N)
func GetOverallRankings(limit int) ([]RankingEntry, error) {
	query := `
		SELECT r.overall_rank, r.student_id, s.name, r.overall_score, r.overall_time_seconds
		FROM results r
		JOIN students s ON r.student_id = s.id
		WHERE r.overall_rank IS NOT NULL
		ORDER BY r.overall_rank ASC
		LIMIT $1
	`

	rows, err := DB.Query(context.Background(), query, limit)
	if err != nil {
		return nil, fmt.Errorf("failed to get rankings: %w", err)
	}
	defer rows.Close()

	var rankings []RankingEntry
	for rows.Next() {
		var entry RankingEntry
		err := rows.Scan(&entry.Rank, &entry.StudentID, &entry.Name, &entry.Score, &entry.TimeSeconds)
		if err != nil {
			continue
		}
		entry.TimeDisplay = formatTime(entry.TimeSeconds)
		rankings = append(rankings, entry)
	}

	return rankings, nil
}

// Get section rankings (top N)
func GetSectionRankings(sectionID, limit int) ([]SectionRankingEntry, error) {
	sectionKey := fmt.Sprintf("%d", sectionID)

	query := `
		SELECT r.student_id, s.name, r.section_scores, r.section_times, r.section_ranks
		FROM results r
		JOIN students s ON r.student_id = s.id
		WHERE r.section_ranks IS NOT NULL
		ORDER BY (r.section_ranks->>$1)::int ASC
		LIMIT $2
	`

	rows, err := DB.Query(context.Background(), query, sectionKey, limit)
	if err != nil {
		return nil, fmt.Errorf("failed to get section rankings: %w", err)
	}
	defer rows.Close()

	var rankings []SectionRankingEntry
	for rows.Next() {
		var studentID int
		var name string
		var scoresJSON, timesJSON, ranksJSON []byte

		err := rows.Scan(&studentID, &name, &scoresJSON, &timesJSON, &ranksJSON)
		if err != nil {
			continue
		}

		var scores, times, ranks map[string]int
		json.Unmarshal(scoresJSON, &scores)
		json.Unmarshal(timesJSON, &times)
		json.Unmarshal(ranksJSON, &ranks)

		entry := SectionRankingEntry{
			Rank:               ranks[sectionKey],
			StudentID:          studentID,
			Name:               name,
			SectionScore:       scores[sectionKey],
			SectionTimeSeconds: times[sectionKey],
			TimeDisplay:        formatTime(times[sectionKey]),
		}
		rankings = append(rankings, entry)
	}

	return rankings, nil
}

// Format seconds to MM:SS
func formatTime(seconds int) string {
	minutes := seconds / 60
	secs := seconds % 60
	return fmt.Sprintf("%d:%02d", minutes, secs)
}

// Get student result with ranks
func GetStudentResult(studentID int) (*Result, error) {
	query := `
		SELECT
			r.student_id, s.name, r.overall_score, r.overall_time_seconds, r.overall_rank,
			r.section_scores, r.section_times, r.section_ranks, r.last_calculated_at
		FROM results r
		JOIN students s ON r.student_id = s.id
		WHERE r.student_id = $1
	`

	var result Result
	var scoresJSON, timesJSON, ranksJSON []byte

	err := DB.QueryRow(context.Background(), query, studentID).Scan(
		&result.StudentID,
		&result.Name,
		&result.OverallScore,
		&result.OverallTimeSeconds,
		&result.OverallRank,
		&scoresJSON,
		&timesJSON,
		&ranksJSON,
		&result.LastCalculatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("failed to get student result: %w", err)
	}

	json.Unmarshal(scoresJSON, &result.SectionScores)
	json.Unmarshal(timesJSON, &result.SectionTimeSeconds)
	json.Unmarshal(ranksJSON, &result.SectionRanks)

	return &result, nil
}
