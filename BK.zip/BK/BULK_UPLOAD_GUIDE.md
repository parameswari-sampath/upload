# Bulk Student Upload Guide

## Endpoint

```http
POST /api/students/bulk
Content-Type: application/json
```

## Request Format

```json
{
  "students": [
    {"name": "Student Name", "email": "email@example.com"},
    {"name": "Another Student", "email": "another@example.com"}
  ]
}
```

## Response Format

```json
{
  "success": true,
  "total": 10,
  "added": 8,
  "skipped": 2,
  "errors": [],
  "error_count": 0
}
```

### Response Fields:
- `total`: Total students in the request
- `added`: Successfully added new students
- `skipped`: Skipped (duplicates or empty entries)
- `errors`: Array of error messages
- `error_count`: Number of errors encountered

---

## Converting Excel to JSON

### Option 1: Using Online Tool
1. Export your Excel file as CSV
2. Use https://www.convertcsv.com/csv-to-json.htm
3. Map columns: `name` and `email`
4. Copy the JSON output

### Option 2: Using Python Script

```python
import pandas as pd
import json

# Read Excel file
df = pd.read_excel('students.xlsx')

# Convert to JSON format
students = []
for index, row in df.iterrows():
    students.append({
        "name": row['Name'],  # Adjust column name as per your Excel
        "email": row['Email']  # Adjust column name as per your Excel
    })

# Create final JSON
output = {"students": students}

# Save to file
with open('students_upload.json', 'w') as f:
    json.dump(output, f, indent=2)

print(f"Converted {len(students)} students to JSON")
```

### Option 3: Using Frontend (Recommended for 20k students)

```javascript
// In your React/Next.js admin panel
const handleExcelUpload = async (file) => {
  // Use a library like 'xlsx' or 'exceljs'
  const XLSX = require('xlsx');

  const reader = new FileReader();
  reader.onload = async (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const jsonData = XLSX.utils.sheet_to_json(sheet);

    // Convert to required format
    const students = jsonData.map(row => ({
      name: row.Name || row.name,
      email: row.Email || row.email
    }));

    // Upload in batches for large files
    const batchSize = 1000;
    for (let i = 0; i < students.length; i += batchSize) {
      const batch = students.slice(i, i + batchSize);

      const response = await fetch('http://localhost:4000/api/students/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ students: batch })
      });

      const result = await response.json();
      console.log(`Batch ${i/batchSize + 1}:`, result);
    }
  };

  reader.readAsArrayBuffer(file);
};
```

---

## Testing with Sample Data

Use the provided `sample_students.json` file:

```bash
curl -X POST http://localhost:4000/api/students/bulk \
  -H "Content-Type: application/json" \
  -d @sample_students.json
```

---

## Excel Template

Your Excel file should have these columns:

| Name | Email |
|------|-------|
| John Doe | john.doe@example.com |
| Jane Smith | jane.smith@example.com |
| ... | ... |

**Important:**
- Column names can be "Name" and "Email" (case-insensitive)
- Email must be unique
- Empty rows will be skipped
- Duplicate emails will be skipped

---

## Handling 20k Students

For 20,000 students, upload in batches:

1. **Split into batches of 1000-2000 students**
2. **Upload each batch sequentially**
3. **Track progress in your frontend**

Example batch processing:

```bash
# Split your JSON into multiple files
# students_batch_1.json (1-1000)
# students_batch_2.json (1001-2000)
# etc.

# Upload each batch
curl -X POST http://localhost:4000/api/students/bulk \
  -H "Content-Type: application/json" \
  -d @students_batch_1.json

curl -X POST http://localhost:4000/api/students/bulk \
  -H "Content-Type: application/json" \
  -d @students_batch_2.json
```

---

## Error Handling

The endpoint will:
- ✅ Skip duplicates automatically (by email)
- ✅ Skip empty entries
- ✅ Continue processing even if some entries fail
- ✅ Return detailed error messages

Example error response:
```json
{
  "success": true,
  "total": 100,
  "added": 95,
  "skipped": 3,
  "errors": [
    "Row 45: Failed to add invalid@email - invalid format",
    "Row 67: Failed to check email test@test.com"
  ],
  "error_count": 2
}
```

---

## Notes

- Duplicates are checked by email address
- Each student gets a unique invite token automatically
- Emails are NOT sent automatically (use `/api/students/send-invite` separately)
- Maximum recommended batch size: 2000 students per request
- Total time for 20k students: ~2-3 minutes (in batches)
