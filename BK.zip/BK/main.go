package main

import (
	"log"
	"smart-mcq/internal/database"
	"smart-mcq/internal/worker"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/joho/godotenv"
)

func main() {
	// Load environment variables
	err := godotenv.Load()
	if err != nil {
		log.Println("No .env file found, using environment variables")
	}

	// Connect to Postgres and run migrations
	database.Connect()
	database.Migrate()

	// Start background ranking worker
	worker.StartRankingWorker()

	// Initialize Fiber
	app := fiber.New()

	// Enable CORS for all origins
	app.Use(cors.New(cors.Config{
		AllowOrigins: "*",
		AllowMethods: "GET,POST,PUT,DELETE,OPTIONS",
		AllowHeaders: "Origin,Content-Type,Accept,Authorization,X-Admin-API-Key",
	}))

	// Health check
	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("MCQ Platform API is running 🚀")
	})

	// Get all students endpoint
	app.Get("/api/students", func(c *fiber.Ctx) error {
		students, err := database.GetAllStudents()
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}
		return c.JSON(students)
	})

	// Add student endpoint (without sending email)
	app.Post("/api/students", func(c *fiber.Ctx) error {
		var payload struct {
			Name  string `json:"name"`
			Email string `json:"email"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		if payload.Name == "" || payload.Email == "" {
			return c.Status(400).JSON(fiber.Map{"error": "Name and email are required"})
		}

		err := database.AddStudent(payload.Name, payload.Email)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Student added successfully"})
	})

	// Bulk add students endpoint (for Excel upload)
	app.Post("/api/students/bulk", func(c *fiber.Ctx) error {
		var payload struct {
			Students []struct {
				Name  string `json:"name"`
				Email string `json:"email"`
			} `json:"students"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		if len(payload.Students) == 0 {
			return c.Status(400).JSON(fiber.Map{"error": "No students provided"})
		}

		successCount, skipCount, errors, err := database.BulkAddStudents(payload.Students)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{
			"success":       true,
			"total":         len(payload.Students),
			"added":         successCount,
			"skipped":       skipCount,
			"errors":        errors,
			"error_count":   len(errors),
		})
	})

	// Send invite email to single student
	app.Post("/api/students/send-invite", func(c *fiber.Ctx) error {
		var payload struct {
			Email string `json:"email"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		if payload.Email == "" {
			return c.Status(400).JSON(fiber.Map{"error": "Email is required"})
		}

		err := database.SendInviteEmail(payload.Email)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Invite email sent successfully"})
	})

	// Send invite emails to all students
	app.Post("/api/students/send-invite-all", func(c *fiber.Ctx) error {
		successCount, failCount, errors, err := database.SendInviteEmailToAll()
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{
			"success":     true,
			"total":       successCount + failCount,
			"sent":        successCount,
			"failed":      failCount,
			"errors":      errors,
			"error_count": len(errors),
		})
	})

	// Validate token endpoint
	app.Post("/api/test/validate-token", func(c *fiber.Ctx) error {
		var payload struct {
			Token string `json:"token"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		if payload.Token == "" {
			return c.Status(400).JSON(fiber.Map{"error": "Token is required"})
		}

		// Validate token
		student, err := database.ValidateInviteToken(payload.Token)
		if err != nil {
			return c.Status(401).JSON(fiber.Map{"error": "Invalid or expired token"})
		}

		// Check if student has already attended
		hasAttended, err := database.HasStudentAttended(student.ID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{
			"student_id":   student.ID,
			"name":         student.Name,
			"email":        student.Email,
			"has_attended": hasAttended,
		})
	})

	// Get test data endpoint
	app.Get("/api/test", func(c *fiber.Ctx) error {
		testData, err := database.GetTestData()
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}
		return c.JSON(testData)
	})

	// Start test session endpoint
	app.Post("/api/test/start", func(c *fiber.Ctx) error {
		var payload struct {
			StudentID int `json:"student_id"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		// Check if student already attended
		attended, err := database.HasStudentAttended(payload.StudentID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}
		if attended {
			return c.Status(403).JSON(fiber.Map{"error": "Student has already attended the test"})
		}

		// Start session
		err = database.StartTestSession(payload.StudentID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Test session started"})
	})

	// Submit answer endpoint
	app.Post("/api/test/answer", func(c *fiber.Ctx) error {
		var response database.StudentResponse

		if err := c.BodyParser(&response); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		err := database.SaveStudentResponse(response)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Answer saved"})
	})

	// Complete test endpoint
	app.Post("/api/test/complete", func(c *fiber.Ctx) error {
		var payload struct {
			StudentID int `json:"student_id"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		err := database.CompleteTestSession(payload.StudentID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Test completed"})
	})

	// Get student responses endpoint
	app.Get("/api/test/responses/:student_id", func(c *fiber.Ctx) error {
		studentID, err := c.ParamsInt("student_id")
		if err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid student ID"})
		}

		responses, err := database.GetStudentResponses(studentID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(responses)
	})

	// Track section transition endpoint
	app.Post("/api/test/section-transition", func(c *fiber.Ctx) error {
		var payload struct {
			StudentID int `json:"student_id"`
			SectionID int `json:"section_id"`
		}

		if err := c.BodyParser(&payload); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
		}

		err := database.TrackSectionTransition(payload.StudentID, payload.SectionID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{"success": true, "message": "Section transition tracked"})
	})

	// Get overall rankings endpoint
	app.Get("/api/rankings/overall", func(c *fiber.Ctx) error {
		limit := c.QueryInt("limit", 100)
		if limit > 100 {
			limit = 100
		}

		rankings, err := database.GetOverallRankings(limit)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{
			"rankings": rankings,
			"total":    len(rankings),
		})
	})

	// Get section rankings endpoint
	app.Get("/api/rankings/section/:section_id", func(c *fiber.Ctx) error {
		sectionID, err := c.ParamsInt("section_id")
		if err != nil || sectionID < 1 || sectionID > 4 {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid section ID (must be 1-4)"})
		}

		limit := c.QueryInt("limit", 100)
		if limit > 100 {
			limit = 100
		}

		rankings, err := database.GetSectionRankings(sectionID, limit)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		sectionNames := map[int]string{
			1: "Data Structures",
			2: "Algorithms",
			3: "Database Concepts",
			4: "Web Development",
		}

		return c.JSON(fiber.Map{
			"section_id":   sectionID,
			"section_name": sectionNames[sectionID],
			"rankings":     rankings,
			"total":        len(rankings),
		})
	})

	// Get student result endpoint
	app.Get("/api/result/:student_id", func(c *fiber.Ctx) error {
		studentID, err := c.ParamsInt("student_id")
		if err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid student ID"})
		}

		result, err := database.GetStudentResult(studentID)
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(result)
	})

	// Admin endpoint - Reset database (drop and recreate all tables)
	app.Post("/api/admin/reset-database", func(c *fiber.Ctx) error {
		err := database.ResetDatabase()
		if err != nil {
			return c.Status(500).JSON(fiber.Map{"error": err.Error()})
		}

		return c.JSON(fiber.Map{
			"success": true,
			"message": "Database reset successfully. All tables dropped and recreated.",
		})
	})

	// Start server
	log.Println("Server running on :4000")
	if err := app.Listen(":4000"); err != nil {
		log.Fatal(err)
	}
}
