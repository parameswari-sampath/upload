'use client';

import { useEffect, useState, useCallback, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useTest } from '@/context/TestContext';
import { api } from '@/lib/api';
import { formatTime } from '@/lib/utils';
import { useTimer } from '@/hooks/useTimer';
import type { Option } from '@/lib/types';

function TestPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const {
    state,
    dispatch,
    getCurrentSection,
    getCurrentQuestion,
    getTotalQuestions,
    getCurrentQuestionNumber,
  } = useTest();

  const [selectedOption, setSelectedOption] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [acceptedRules, setAcceptedRules] = useState(false);

  const currentSection = getCurrentSection();
  const currentQuestion = getCurrentQuestion();
  const totalQuestions = getTotalQuestions();
  const currentQuestionNumber = getCurrentQuestionNumber();

  // Check if token is present in URL
  useEffect(() => {
    const token = searchParams.get('token');
    
    if (!token && !state.student && !isValidating) {
      router.push('/');
    }
  }, [searchParams, state.student, isValidating, router]);

  const handleStartTest = async () => {
    const token = searchParams.get('token');
    if (!token) {
      setError('No token provided');
      return;
    }

    setIsValidating(true);
    setError(null);

    try {
      const response = await api.validateToken(token);

      // Check if already attended
      if (response.has_attended) {
        router.push('/banned');
        return;
      }

      // Set student in context
      dispatch({
        type: 'SET_STUDENT',
        payload: {
          id: response.student_id,
          name: response.name,
          email: response.email,
          hasAttended: response.has_attended,
        },
      });

      // Fetch test configuration
      const testConfig = await api.getTestData();
      dispatch({ type: 'SET_TEST_CONFIG', payload: testConfig });

      // Start the test
      await api.startTest(response.student_id);
      dispatch({ type: 'START_TEST' });

      setIsValidating(false);
    } catch (err) {
      console.error('Token validation failed:', err);
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Invalid or expired token');
      setIsValidating(false);
    }
  };

  // Overall timer
  useTimer({
    isActive: state.isTestActive && state.overallTimeRemaining > 0,
    onTick: useCallback(() => {
      dispatch({ type: 'TICK_OVERALL_TIMER' });
    }, [dispatch]),
  });

  // Section timer
  useTimer({
    isActive: state.isTestActive && state.sectionTimeRemaining > 0,
    onTick: useCallback(() => {
      dispatch({ type: 'TICK_SECTION_TIMER' });
    }, [dispatch]),
  });

  // Track section transition on section change
  useEffect(() => {
    if (state.isTestActive && state.student && currentSection) {
      api
        .trackSectionTransition(state.student.id, currentSection.section_id)
        .catch((err) => console.error('Failed to track section transition:', err));
    }
  }, [state.currentSectionIndex, state.isTestActive, state.student, currentSection]);

  // Auto-submit when overall timer expires
  useEffect(() => {
    if (state.isTestActive && state.overallTimeRemaining === 0) {
      handleCompleteTest();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.overallTimeRemaining, state.isTestActive]);

  // Auto-submit remaining questions when section timer expires
  useEffect(() => {
    if (
      state.isTestActive &&
      state.sectionTimeRemaining === 0 &&
      currentSection &&
      state.student
    ) {
      handleSectionTimeout();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.sectionTimeRemaining, state.isTestActive]);

  const handleSectionTimeout = async () => {
    if (!currentSection || !state.student) return;

    const remainingQuestions = currentSection.questions.slice(state.currentQuestionIndex);

    // Submit null for remaining questions in this section
    for (const question of remainingQuestions) {
      try {
        await api.submitAnswer({
          student_id: state.student.id,
          question_id: question.question_id,
          section_id: currentSection.section_id,
          selected_option: 'null',
        });
      } catch (err) {
        console.error('Failed to auto-submit question:', err);
      }
    }

    // Move to next section or complete test
    if (state.currentSectionIndex < (state.testConfig?.sections.length || 0) - 1) {
      dispatch({ type: 'NEXT_SECTION' });
      setSelectedOption('');
    } else {
      handleCompleteTest();
    }
  };

  const handleSubmitAnswer = async () => {
    if (!selectedOption || !state.student || !currentQuestion || !currentSection) return;

    setIsSubmitting(true);
    setError(null);

    try {
      // Submit answer to backend
      await api.submitAnswer({
        student_id: state.student.id,
        question_id: currentQuestion.question_id,
        section_id: currentSection.section_id,
        selected_option: selectedOption,
      });

      // Check if last question in section
      const isLastQuestionInSection =
        state.currentQuestionIndex === currentSection.questions.length - 1;

      if (isLastQuestionInSection) {
        // Check if last section
        const isLastSection =
          state.currentSectionIndex === (state.testConfig?.sections.length || 0) - 1;

        if (isLastSection) {
          // Complete test
          await handleCompleteTest();
        } else {
          // Move to next section
          dispatch({ type: 'NEXT_SECTION' });
          setSelectedOption('');
        }
      } else {
        // Move to next question
        dispatch({ type: 'NEXT_QUESTION' });
        setSelectedOption('');
      }

      setIsSubmitting(false);
    } catch (err) {
      console.error('Failed to submit answer:', err);
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Failed to submit answer. Please try again.');
      setIsSubmitting(false);
    }
  };

  const handleCompleteTest = async () => {
    if (!state.student) return;

    try {
      dispatch({ type: 'SET_SUBMITTING', payload: true });
      await api.completeTest(state.student.id);
      dispatch({ type: 'END_TEST' });
      router.push('/thankyou');
    } catch (err) {
      console.error('Failed to complete test:', err);
      setError('Failed to submit test. Redirecting...');
      setTimeout(() => router.push('/thankyou'), 2000);
    }
  };

  // Show loading during validation
  if (isValidating) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Validating token...</p>
        </div>
      </div>
    );
  }

  // Show rules if token is present but test hasn't started yet
  const token = searchParams.get('token');
  if (token && !state.student) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white shadow-lg rounded-lg p-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                Programming Assessment
              </h1>
              <p className="text-lg text-gray-600">
                Please read the following instructions carefully before starting the test.
              </p>
            </div>

            <div className="space-y-6 mb-8">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-3">Test Instructions</h2>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span>Total Duration: 4 minutes</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span>Number of Sections: 4 sections</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span>Questions per Section: 5 questions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span>Time per Section: 1 minute</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span>Total Questions: 20 questions</span>
                  </li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-3">Important Rules</h2>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Do not refresh the page during the test</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Do not navigate away from the test page</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Answer all questions within the time limit</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Test will auto-submit when time expires</span>
                  </li>
                </ul>
              </div>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
                <p className="text-red-600">{error}</p>
              </div>
            )}

            <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-md">
              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptedRules}
                  onChange={(e) => setAcceptedRules(e.target.checked)}
                  className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <span className="text-sm text-gray-700">
                  I have read and understood all the test instructions and rules above. 
                  I agree to follow them during the test and understand that any violation 
                  may result in test disqualification.
                </span>
              </label>
            </div>

            <div className="text-center">
              <button
                onClick={handleStartTest}
                disabled={isValidating || !acceptedRules}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-3 px-8 rounded-lg text-lg transition-colors"
              >
                {isValidating ? 'Starting Test...' : 'Start Test'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show loading if test is not ready
  if (!state.student || !state.testConfig || !currentSection || !currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <div className="text-center">
            <div className="text-red-600 text-5xl mb-4">⚠</div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Error</h1>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  // Calculate section progress
  const sectionProgress = state.currentQuestionIndex + 1;
  const sectionTotal = currentSection.questions.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Fixed Header - Timers */}
      <div className="bg-white shadow-md border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            {/* Overall Timer */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-600">Overall Time:</span>
              <div
                className={`text-2xl font-bold ${
                  state.overallTimeRemaining <= 60 ? 'text-red-600' : 'text-blue-600'
                }`}
              >
                {formatTime(state.overallTimeRemaining)}
              </div>
            </div>

            {/* Section Info */}
            <div className="text-center">
              <div className="text-sm font-medium text-gray-600">
                Section {state.currentSectionIndex + 1} of 4
              </div>
              <div className="text-xs text-gray-500">{currentSection.section_name}</div>
            </div>

            {/* Section Timer */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-600">Section Time:</span>
              <div
                className={`text-2xl font-bold ${
                  state.sectionTimeRemaining <= 15 ? 'text-red-600' : 'text-green-600'
                }`}
              >
                {formatTime(state.sectionTimeRemaining)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          {/* Progress */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-600">
                Question {currentQuestionNumber} of {totalQuestions}
              </span>
              <span className="text-sm font-medium text-gray-600">
                Section Progress: {sectionProgress}/{sectionTotal}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${(currentQuestionNumber / totalQuestions) * 100}%`,
                }}
              ></div>
            </div>
          </div>

          {/* Question */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              {currentQuestion.question_text}
            </h2>

            {/* Options */}
            <div className="space-y-4">
              {currentQuestion.options.map((option: Option) => (
                <label
                  key={option.option_id}
                  className={`flex items-center p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                    selectedOption === option.option_id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="answer"
                    value={option.option_id}
                    checked={selectedOption === option.option_id}
                    onChange={(e) => setSelectedOption(e.target.value)}
                    className="w-5 h-5 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-4 text-lg text-gray-900">
                    <span className="font-semibold mr-2">{option.option_id}.</span>
                    {option.text}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              onClick={handleSubmitAnswer}
              disabled={!selectedOption || isSubmitting}
              className="px-8 py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 disabled:cursor-not-allowed"
            >
              {isSubmitting
                ? 'Submitting...'
                : state.currentQuestionIndex === currentSection.questions.length - 1 &&
                  state.currentSectionIndex === (state.testConfig?.sections.length || 0) - 1
                ? 'Submit Test'
                : state.currentQuestionIndex === currentSection.questions.length - 1
                ? 'Next Section'
                : 'Next Question'}
            </button>
          </div>

          {/* Helper Text */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              Select an option to proceed. You cannot go back to previous questions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TestPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    }>
      <TestPageContent />
    </Suspense>
  );
}
