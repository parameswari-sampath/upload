export default function ThankYouPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-12 text-center">
        {/* Success Icon */}
        <div className="mb-6">
          <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <svg
              className="w-12 h-12 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Test Submitted!</h1>

        {/* Message */}
        <p className="text-lg text-gray-700 mb-6">
          Thank you for completing the test.
        </p>

        <p className="text-gray-600 mb-4">Your responses have been recorded successfully.</p>

        <div className="pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-500">
            Results will be shared with you via email.
          </p>
        </div>

        {/* Footer Note */}
        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-600">
            You may now close this window.
          </p>
        </div>
      </div>
    </div>
  );
}
