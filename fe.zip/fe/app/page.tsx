'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';
import { useTest } from '@/context/TestContext';
import { getSecondsUntil, isTimePast, formatTime } from '@/lib/utils';

function HomeContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { state, dispatch } = useTest();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [countdownSeconds, setCountdownSeconds] = useState(0);
  const [testStartTime, setTestStartTime] = useState<string>('');

  // Validate token on mount
  useEffect(() => {
    const token = searchParams.get('token');

    if (!token) {
      setError('No token provided. Please check your invitation link.');
      setLoading(false);
      return;
    }

    validateToken(token);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const validateToken = async (token: string) => {
    try {
      const response = await api.validateToken(token);

      // Check if already attended
      if (response.has_attended) {
        router.push('/banned');
        return;
      }

      // Set student in context
      dispatch({
        type: 'SET_STUDENT',
        payload: {
          id: response.student_id,
          name: response.name,
          email: response.email,
          hasAttended: response.has_attended,
        },
      });

      // Fetch test configuration
      const testConfig = await api.getTestData();
      dispatch({ type: 'SET_TEST_CONFIG', payload: testConfig });
      setTestStartTime(testConfig.start_time);

      setLoading(false);
    } catch (err) {
      console.error('Token validation failed:', err);
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Invalid or expired token');
      setLoading(false);
    }
  };

  // Countdown timer
  useEffect(() => {
    if (!testStartTime || loading) return;

    const updateCountdown = () => {
      const seconds = getSecondsUntil(testStartTime);
      setCountdownSeconds(seconds);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [testStartTime, loading]);

  const handleStartTest = async () => {
    if (!state.student) return;

    try {
      setLoading(true);
      await api.startTest(state.student.id);
      dispatch({ type: 'START_TEST' });
      router.push('/test');
    } catch (err) {
      console.error('Failed to start test:', err);
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Failed to start test');
      setLoading(false);
    }
  };

  const canStartTest = testStartTime && isTimePast(testStartTime);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <div className="text-center">
            <div className="text-red-600 text-5xl mb-4">⚠</div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Error</h1>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
              MCQ Test Platform
            </h1>
            <p className="text-lg text-gray-600">
              Welcome, <span className="font-semibold text-blue-600">{state.student?.name}</span>!
            </p>
          </div>

          {/* Test Information */}
          <div className="mb-8 p-6 bg-blue-50 rounded-xl border border-blue-100">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Test Details</h2>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Total Duration: <strong>4 minutes</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Sections: <strong>4 sections</strong> (Data Structures, Algorithms, Database, Web Dev)</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Section Duration: <strong>1 minute each</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Questions: <strong>5 questions per section</strong> (20 total)</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Test Start Time: <strong>{testStartTime}</strong></span>
              </li>
            </ul>
          </div>

          {/* Instructions */}
          <div className="mb-8 p-6 bg-yellow-50 rounded-xl border border-yellow-100">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Important Instructions</h2>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span>You can only take this test <strong>once</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span>Questions are shown <strong>one at a time</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span><strong>You cannot go back</strong> to previous questions</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span>You <strong>must answer</strong> each question to proceed</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span>When section timer expires, remaining questions auto-submit</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span>Ensure <strong>stable internet connection</strong></span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">▸</span>
                <span><strong>Do not refresh</strong> or close the browser</span>
              </li>
            </ul>
          </div>

          {/* Disclaimer */}
          <div className="mb-8 p-6 bg-gray-50 rounded-xl border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Disclaimer</h2>
            <p className="text-gray-700 text-sm leading-relaxed">
              By starting this test, you agree that:
            </p>
            <ul className="mt-2 space-y-1 text-gray-700 text-sm">
              <li className="flex items-start">
                <span className="text-gray-400 mr-2">•</span>
                <span>Your answers will be automatically saved</span>
              </li>
              <li className="flex items-start">
                <span className="text-gray-400 mr-2">•</span>
                <span>The test will auto-submit when time expires</span>
              </li>
              <li className="flex items-start">
                <span className="text-gray-400 mr-2">•</span>
                <span>You will not engage in any form of cheating or malpractice</span>
              </li>
            </ul>
          </div>

          {/* Countdown or Start Button */}
          <div className="text-center">
            {!canStartTest ? (
              <div className="mb-6">
                <p className="text-lg text-gray-700 mb-2">Test starts in</p>
                <div className="text-4xl font-bold text-blue-600">
                  {formatTime(countdownSeconds)}
                </div>
                <p className="text-sm text-gray-500 mt-2">Please wait until {testStartTime}</p>
              </div>
            ) : (
              <button
                onClick={handleStartTest}
                disabled={loading}
                className="w-full md:w-auto px-12 py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 disabled:cursor-not-allowed"
              >
                {loading ? 'Starting...' : 'Start Test'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        </div>
      }
    >
      <HomeContent />
    </Suspense>
  );
}
