'use client';

import { useState } from 'react';
import * as XLSX from 'xlsx';

const ADMIN_PASSWORD = 'admin123'; // Hardcoded password

interface Student {
  name: string;
  email: string;
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploadingExcel, setUploadingExcel] = useState(false);
  const [sendingEmails, setSendingEmails] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number } | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Invalid password');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/students`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({ type: 'success', text: 'Student added successfully!' });
        setName('');
        setEmail('');
      } else {
        setMessage({ type: 'error', text: data.error || 'Failed to add student' });
      }
    } catch {
      setMessage({ type: 'error', text: 'Network error. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleExcelUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingExcel(true);
    setMessage(null);
    setUploadProgress(null);

    try {
      // Read the Excel file
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as Record<string, unknown>[];

      // Extract students from Excel
      const students: Student[] = [];
      for (const row of jsonData) {
        // Support both formats: "Name" or "name", "Email address" or "Email" or "email"
        const studentName = row['Name'] || row['name'] || row['Student Name'];
        const studentEmail = row['Email address'] || row['Email'] || row['email'];

        if (studentName && studentEmail) {
          students.push({
            name: String(studentName).trim(),
            email: String(studentEmail).trim(),
          });
        }
      }

      if (students.length === 0) {
        setMessage({ type: 'error', text: 'No valid students found in Excel file' });
        setUploadingExcel(false);
        return;
      }

      // Show upload starting feedback
      setMessage({ type: 'success', text: `Processing ${students.length} students from Excel...` });
      setUploadProgress({ current: 0, total: students.length });

      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/students/bulk`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ students }),
        });

        const result = await response.json();

        setUploadProgress({ current: students.length, total: students.length });

        if (response.ok && result.success) {
          setMessage({
            type: 'success',
            text: `Upload complete! Total: ${result.total}, Added: ${result.added}, Skipped: ${result.skipped}, Errors: ${result.error_count}`,
          });
        } else {
          setMessage({
            type: 'error',
            text: `Upload failed. Errors: ${result.errors?.join(', ') || 'Unknown error'}`,
          });
        }
      } catch {
        setMessage({
          type: 'error',
          text: 'Network error during bulk upload. Please try again.',
        });
      }

      // Reset file input
      e.target.value = '';
    } catch {
      setMessage({ type: 'error', text: 'Failed to parse Excel file. Please check the format.' });
    } finally {
      setUploadingExcel(false);
      setUploadProgress(null);
    }
  };

  const handleSendEmailsToAll = async () => {
    if (!confirm('Are you sure you want to send test invitations to ALL students? This may take several minutes.')) {
      return;
    }

    setSendingEmails(true);
    setMessage({ type: 'success', text: 'Sending emails to all students... This may take several minutes.' });

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/students/send-invite-all`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const result = await response.json();

      if (response.ok && result.success) {
        setMessage({
          type: 'success',
          text: `Email sending complete! Total: ${result.total}, Sent: ${result.sent}, Failed: ${result.failed}`,
        });
      } else {
        setMessage({
          type: 'error',
          text: `Email sending failed. ${result.errors?.join(', ') || 'Unknown error'}`,
        });
      }
    } catch {
      setMessage({
        type: 'error',
        text: 'Network error while sending emails. Please try again.',
      });
    } finally {
      setSendingEmails(false);
    }
  };

  // Show login screen if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-100 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Login</h1>
            <p className="text-gray-600">Enter password to access admin panel</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-gray-900 bg-white"
                placeholder="Enter admin password"
              />
            </div>

            {authError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
                {authError}
              </div>
            )}

            <button
              type="submit"
              className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Login
            </button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600">
              <strong>Default password:</strong> admin123
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-100 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          {/* Header */}
          <div className="mb-8 flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Panel</h1>
              <p className="text-gray-600">Add students to the MCQ test platform</p>
            </div>
            <button
              onClick={() => setIsAuthenticated(false)}
              className="px-4 py-2 text-sm text-red-600 hover:text-red-700 font-medium"
            >
              Logout
            </button>
          </div>

          {/* Send Emails to All Button */}
          <div className="mb-8 p-6 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">📧 Send Test Invitations</h2>
                <p className="text-sm text-gray-600">Send email invitations to all registered students</p>
              </div>
              <button
                onClick={handleSendEmailsToAll}
                disabled={sendingEmails}
                className="px-6 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 disabled:cursor-not-allowed"
              >
                {sendingEmails ? 'Sending...' : 'Send to All Students'}
              </button>
            </div>

            {sendingEmails && (
              <div className="mt-4 p-4 bg-orange-100 border border-orange-300 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-600"></div>
                  <p className="text-sm text-orange-900 font-medium">
                    Sending emails to all students... This may take several minutes. Please wait.
                  </p>
                </div>
              </div>
            )}

            <div className="mt-4 p-3 bg-white rounded-lg border border-gray-200">
              <p className="text-xs text-gray-600">
                ⚠️ <strong>Warning:</strong> This will send test invitation emails to ALL students in the database.
                Each student will receive a unique test link with their token.
              </p>
            </div>
          </div>

          {/* Excel Upload Section */}
          <div className="mb-8 p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border border-green-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">📊 Bulk Upload via Excel</h2>
            <p className="text-sm text-gray-600 mb-4">
              Upload an Excel file (.xlsx, .xls) with columns: <strong>Name</strong> and <strong>Email address</strong>
            </p>

            <div className="flex items-center gap-4">
              <label className="flex-1">
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleExcelUpload}
                  disabled={uploadingExcel}
                  className="block w-full text-sm text-gray-900 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 file:cursor-pointer disabled:opacity-50"
                />
              </label>
            </div>

            {uploadProgress && (
              <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex justify-between text-sm font-medium text-blue-900 mb-2">
                  <span>
                    {uploadProgress.current === 0
                      ? '📤 Uploading to server...'
                      : uploadProgress.current === uploadProgress.total
                      ? '✓ Upload complete!'
                      : '📤 Uploading...'}
                  </span>
                  <span className="font-bold">{uploadProgress.current} / {uploadProgress.total}</span>
                </div>
                <div className="w-full bg-blue-200 rounded-full h-3">
                  <div
                    className="bg-blue-600 h-3 rounded-full transition-all duration-500 flex items-center justify-center"
                    style={{ width: `${(uploadProgress.current / uploadProgress.total) * 100}%` }}
                  >
                    {uploadProgress.current > 0 && (
                      <span className="text-[10px] text-white font-bold">
                        {Math.round((uploadProgress.current / uploadProgress.total) * 100)}%
                      </span>
                    )}
                  </div>
                </div>
                {uploadProgress.current === 0 && (
                  <p className="text-xs text-blue-700 mt-2 animate-pulse">
                    Please wait, sending {uploadProgress.total} students to backend...
                  </p>
                )}
              </div>
            )}

            <div className="mt-4 p-3 bg-white rounded-lg border border-gray-200">
              <p className="text-xs text-gray-600 font-semibold mb-1">Excel Format Example:</p>
              <table className="text-xs text-gray-700 w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-1 px-2">S.No</th>
                    <th className="text-left py-1 px-2">Name</th>
                    <th className="text-left py-1 px-2">Email address</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-1 px-2">1</td>
                    <td className="py-1 px-2">John Doe</td>
                    <td className="py-1 px-2">john@example.com</td>
                  </tr>
                  <tr>
                    <td className="py-1 px-2">2</td>
                    <td className="py-1 px-2">Jane Smith</td>
                    <td className="py-1 px-2">jane@example.com</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex-1 h-px bg-gray-300"></div>
            <span className="text-sm text-gray-500 font-medium">OR Add Manually</span>
            <div className="flex-1 h-px bg-gray-300"></div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name Input */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Student Name
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-gray-900 bg-white"
                placeholder="Enter student name"
              />
            </div>

            {/* Email Input */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Student Email
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-gray-900 bg-white"
                placeholder="Enter student email"
              />
            </div>

            {/* Message Display */}
            {message && (
              <div
                className={`p-4 rounded-lg ${
                  message.type === 'success'
                    ? 'bg-green-50 border border-green-200 text-green-800'
                    : 'bg-red-50 border border-red-200 text-red-800'
                }`}
              >
                {message.text}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 disabled:cursor-not-allowed"
            >
              {loading ? 'Adding Student...' : 'Add Student'}
            </button>
          </form>

          {/* Info Box */}
          <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-100">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">Note:</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Students will receive an email invitation with their test link</li>
              <li>• Each student can only take the test once</li>
              <li>• The test link contains a unique token for authentication</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
