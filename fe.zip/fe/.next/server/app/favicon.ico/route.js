var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__827bc745._.js")
R.c("server/chunks/[root-of-the-server]__41237d6d._.js")
R.m(15934)
R.m(39989)
module.exports=R.m(39989).exports
