globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/bd95e149251277ff.js",
      "static/chunks/acc01eaeb231b6e8.js",
      "static/chunks/turbopack-a127dceda619394b.js"
    ],
    "/_error": [
      "static/chunks/e98037624ff2044f.js",
      "static/chunks/acc01eaeb231b6e8.js",
      "static/chunks/turbopack-f3430900a0fbf9ff.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f61049299b636fc5.js",
    "static/chunks/ebf4d698258fec8b.js",
    "static/chunks/667cce55352292c1.js",
    "static/chunks/5c1c2c17e286e529.js",
    "static/chunks/turbopack-917cb6dc48e6a268.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];