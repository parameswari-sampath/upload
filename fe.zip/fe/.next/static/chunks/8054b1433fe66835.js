__turbopack_load_page_chunks__("/_app", [
  "static/chunks/bd95e149251277ff.js",
  "static/chunks/acc01eaeb231b6e8.js",
  "static/chunks/turbopack-a127dceda619394b.js"
])
