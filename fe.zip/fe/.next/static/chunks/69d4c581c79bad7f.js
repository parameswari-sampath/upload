__turbopack_load_page_chunks__("/_error", [
  "static/chunks/e98037624ff2044f.js",
  "static/chunks/acc01eaeb231b6e8.js",
  "static/chunks/turbopack-f3430900a0fbf9ff.js"
])
