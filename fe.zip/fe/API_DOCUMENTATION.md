# MCQ Test Platform API Documentation

## Overview
Backend API for conducting online MCQ tests with real-time rankings, built with Go, Fiber, and PostgreSQL.

---

## Environment Variables (.env)

```env
# Mailing service
ZEPTO_API_URL=https://api.zeptomail.in/v1.1/email
ZEPTO_API_KEY=your_api_key
ZEPTO_FROM=no-reply@smart-mcq.com

# Database service
DB_HOST=localhost
DB_PORT=5432
DB_USER=mcqadmin
DB_PASSWORD=mcqpass123
DB_NAME=mcqdb

# Test configuration
TEST_START_TIME=11:00:00
TEST_TOTAL_DURATION_MINUTES=4
FRONTEND_URL=http://localhost:3001
```

---

## System Features

### ✅ Background Ranking Worker
- Runs every **10 seconds**
- Automatically calculates scores and rankings
- Updates `results` table with latest rankings
- Handles both overall and section-wise rankings

### ✅ One-Time Test Attendance
- Students can only take the test once
- Session tracking prevents retakes
- Token-based authentication

### ✅ Time Validation
- Test expires after configured duration
- Backend rejects late submissions
- Section timing tracked accurately

---

## API Endpoints

### 1. Student Management

#### Add Student & Send Invite
```http
POST /api/students
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com"
}

Response:
{
  "success": true,
  "message": "Student added successfully"
}
```
**Note:** Automatically sends test invitation email with token

---

### 2. Token Validation

#### Validate Invite Token
```http
POST /api/test/validate-token
Content-Type: application/json

{
  "token": "abc123def456..."
}

Response:
{
  "student_id": 1,
  "name": "John Doe",
  "email": "john@example.com",
  "has_attended": false
}
```

---

### 3. Test Data

#### Get Test Questions & Configuration
```http
GET /api/test

Response:
{
  "test_id": "test_001",
  "test_name": "Programming Assessment",
  "start_time": "11:00:00",
  "total_duration_minutes": 4,
  "sections": [
    {
      "section_id": 1,
      "section_name": "Data Structures",
      "duration_minutes": 1,
      "questions": [
        {
          "question_id": 1,
          "question_text": "What is the time complexity...",
          "options": [
            {"option_id": "A", "text": "O(n)"},
            {"option_id": "B", "text": "O(log n)"},
            ...
          ]
        }
      ]
    }
  ]
}
```

---

### 4. Test Session Management

#### Start Test Session
```http
POST /api/test/start
Content-Type: application/json

{
  "student_id": 1
}

Response:
{
  "success": true,
  "message": "Test session started"
}

Error (if already attended):
403 Forbidden
{
  "error": "Student has already attended the test"
}
```

#### Track Section Transition
```http
POST /api/test/section-transition
Content-Type: application/json

{
  "student_id": 1,
  "section_id": 2
}

Response:
{
  "success": true,
  "message": "Section transition tracked"
}
```
**Frontend should call this when student enters each section**

#### Submit Answer
```http
POST /api/test/answer
Content-Type: application/json

{
  "student_id": 1,
  "question_id": 5,
  "section_id": 2,
  "selected_option": "B"
}

Response:
{
  "success": true,
  "message": "Answer saved"
}

Error (if time expired):
500 Internal Server Error
{
  "error": "test time has expired"
}
```

#### Complete Test
```http
POST /api/test/complete
Content-Type: application/json

{
  "student_id": 1
}

Response:
{
  "success": true,
  "message": "Test completed"
}
```

---

### 5. Rankings

#### Get Overall Rankings (Top 100)
```http
GET /api/rankings/overall?limit=100

Response:
{
  "rankings": [
    {
      "rank": 1,
      "student_id": 45,
      "name": "Alice Johnson",
      "score": 20,
      "time_seconds": 180,
      "time_display": "3:00"
    },
    {
      "rank": 2,
      "student_id": 23,
      "name": "Bob Smith",
      "score": 19,
      "time_seconds": 200,
      "time_display": "3:20"
    }
  ],
  "total": 100
}
```

#### Get Section Rankings (Top 100)
```http
GET /api/rankings/section/1?limit=100

Response:
{
  "section_id": 1,
  "section_name": "Data Structures",
  "rankings": [
    {
      "rank": 1,
      "student_id": 23,
      "name": "Bob Smith",
      "section_score": 5,
      "section_time_seconds": 45,
      "time_display": "0:45"
    }
  ],
  "total": 100
}
```

**Section IDs:**
- 1: Data Structures
- 2: Algorithms
- 3: Database Concepts
- 4: Web Development

#### Get Individual Student Result
```http
GET /api/result/1

Response:
{
  "student_id": 1,
  "name": "John Doe",
  "overall_score": 18,
  "overall_time_seconds": 220,
  "overall_rank": 5,
  "section_scores": {
    "1": 4,
    "2": 5,
    "3": 4,
    "4": 5
  },
  "section_times": {
    "1": 55,
    "2": 60,
    "3": 50,
    "4": 55
  },
  "section_ranks": {
    "1": 12,
    "2": 3,
    "3": 8,
    "4": 2
  },
  "last_calculated_at": "2025-10-01T11:05:30Z"
}
```

---

## Frontend Integration Guide

### Test Flow

```javascript
// 1. Validate token on page load
POST /api/test/validate-token
// Check has_attended flag

// 2. If not attended, get test data
GET /api/test
// Show countdown until start_time

// 3. At start_time, allow test start
POST /api/test/start
// Track section 1 entry
POST /api/test/section-transition (section_id: 1)

// 4. During test
// On each answer change:
POST /api/test/answer

// On section change:
POST /api/test/section-transition (section_id: 2, 3, 4)

// 5. On completion or timeout
POST /api/test/complete

// 6. Show results
GET /api/result/:student_id

// 7. Live rankings (poll every 10-30 seconds)
GET /api/rankings/overall
GET /api/rankings/section/:section_id
```

### Section Timing Strategy

**Frontend manages section transitions:**
- Track current section (1-4)
- Show 1-minute timer per section
- Auto-advance or manual "Next Section" button
- Call `/api/test/section-transition` when entering new section
- Overall 4-minute timer keeps running (cumulative)

### Time Sync

**Important:** Don't rely on client time
- Backend validates time expiry
- If response returns "test time has expired", stop accepting answers
- Auto-submit remaining answers and call `/api/test/complete`

---

## Database Schema

### Tables

1. **students** - Student registration
2. **tests** - Test configuration
3. **test_sessions** - Track test attempts (one per student)
4. **section_transitions** - Track section entry times
5. **test_responses** - Individual answer submissions
6. **results** - Calculated scores and rankings (updated every 10s)

---

## Ranking Algorithm

### Overall Ranking
1. Sort by `overall_score` DESC
2. If tied, sort by `overall_time_seconds` ASC
3. Assign ranks (1, 2, 3...)

### Section Ranking
1. Sort by `section_score` DESC
2. If tied, sort by `section_time_seconds` ASC
3. Assign ranks per section

### Tie-Breaker
- Same score → Lower time gets higher rank
- Same score + same time → Same rank (rare)

---

## Email Template

Students receive HTML email with:
- Test link with token
- Start time
- Duration and section info
- Instructions

Link format: `http://localhost:3001/test?token=<invite_token>`

---

## Running the Server

```bash
# Install dependencies
go mod download

# Run migrations (automatic on startup)
go run main.go

# Server starts on :3000
# Ranking worker runs every 10 seconds
```

---

## Test Data

Location: `test_questions.json`

Structure:
- 4 sections
- 5 questions per section
- 20 total MCQ questions
- Each question has correct answer stored (not sent to frontend)

---

## Admin Endpoints

### Reset Database

```http
POST /api/admin/reset-database

Response:
{
  "success": true,
  "message": "Database reset successfully. All tables dropped and recreated."
}
```

**⚠️ WARNING:** This endpoint will:
- Drop ALL tables (students, tests, results, test_responses, test_sessions, section_transitions)
- Delete ALL data permanently
- Recreate all tables from scratch
- Use only in development/testing environments

---

## Notes

- Rankings update every 10 seconds automatically
- Students can only attend once (enforced at session level)
- Backend validates time expiry on answer submission
- Section times calculated from transition tracking
- Email sent automatically on student registration
- Use `/api/admin/reset-database` to start fresh (development only)
