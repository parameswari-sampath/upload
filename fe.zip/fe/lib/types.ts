// Student types
export interface Student {
  id: number;
  name: string;
  email: string;
  hasAttended: boolean;
}

// Question types
export interface Question {
  question_id: number;
  question_text: string;
  options: Option[];
}

export interface Option {
  option_id: string;
  text: string;
}

// Section types
export interface Section {
  section_id: number;
  section_name: string;
  duration_minutes: number;
  questions: Question[];
}

// Test configuration
export interface TestConfig {
  test_id: string;
  test_name: string;
  start_time: string;
  total_duration_minutes: number;
  sections: Section[];
}

// API Response types
export interface TokenValidationResponse {
  student_id: number;
  name: string;
  email: string;
  has_attended: boolean;
}

export interface ApiResponse<T> {
  success?: boolean;
  message?: string;
  data?: T;
  error?: string;
}

// Answer submission payload
export interface AnswerPayload {
  student_id: number;
  question_id: number;
  section_id: number;
  selected_option: string;
}
