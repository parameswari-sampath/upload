import axios from 'axios';
import type { TokenValidationResponse, TestConfig, AnswerPayload } from './types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

export const api = {
  // Validate token and get student info
  validateToken: async (token: string): Promise<TokenValidationResponse> => {
    const response = await apiClient.post('/api/test/validate-token', { token });
    return response.data;
  },

  // Get test data (questions and configuration)
  getTestData: async (): Promise<TestConfig> => {
    const response = await apiClient.get('/api/test');
    return response.data;
  },

  // Start test session
  startTest: async (studentId: number): Promise<void> => {
    await apiClient.post('/api/test/start', { student_id: studentId });
  },

  // Track section transition
  trackSectionTransition: async (studentId: number, sectionId: number): Promise<void> => {
    await apiClient.post('/api/test/section-transition', {
      student_id: studentId,
      section_id: sectionId,
    });
  },

  // Submit answer
  submitAnswer: async (payload: AnswerPayload): Promise<void> => {
    await apiClient.post('/api/test/answer', payload);
  },

  // Complete test
  completeTest: async (studentId: number): Promise<void> => {
    await apiClient.post('/api/test/complete', { student_id: studentId });
  },
};
