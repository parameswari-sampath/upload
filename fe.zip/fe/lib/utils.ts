// Format seconds to MM:SS display
export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Parse time string (HH:MM:SS) to Date object for today
export function parseTimeToday(timeStr: string): Date {
  const [hours, minutes, seconds] = timeStr.split(':').map(Number);
  const now = new Date();
  now.setHours(hours, minutes, seconds || 0, 0);
  return now;
}

// Check if current time is past the given time
export function isTimePast(timeStr: string): boolean {
  const targetTime = parseTimeToday(timeStr);
  return new Date() >= targetTime;
}

// Get seconds until a specific time today
export function getSecondsUntil(timeStr: string): number {
  const targetTime = parseTimeToday(timeStr);
  const now = new Date();
  const diff = targetTime.getTime() - now.getTime();
  return Math.max(0, Math.floor(diff / 1000));
}
