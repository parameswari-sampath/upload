'use client';

import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import type { Student, TestConfig, Section } from '@/lib/types';

// State interface
interface TestState {
  student: Student | null;
  testConfig: TestConfig | null;
  currentSectionIndex: number; // 0-3 (array index)
  currentQuestionIndex: number; // 0-4 (within section)
  overallTimeRemaining: number; // seconds
  sectionTimeRemaining: number; // seconds
  testStartedAt: Date | null;
  isTestActive: boolean;
  isSubmitting: boolean;
}

// Action types
type TestAction =
  | { type: 'SET_STUDENT'; payload: Student }
  | { type: 'SET_TEST_CONFIG'; payload: TestConfig }
  | { type: 'START_TEST' }
  | { type: 'NEXT_QUESTION' }
  | { type: 'NEXT_SECTION' }
  | { type: 'TICK_OVERALL_TIMER' }
  | { type: 'TICK_SECTION_TIMER' }
  | { type: 'RESET_SECTION_TIMER' }
  | { type: 'SET_SUBMITTING'; payload: boolean }
  | { type: 'END_TEST' };

// Initial state
const initialState: TestState = {
  student: null,
  testConfig: null,
  currentSectionIndex: 0,
  currentQuestionIndex: 0,
  overallTimeRemaining: 240, // 4 minutes in seconds
  sectionTimeRemaining: 60, // 1 minute in seconds
  testStartedAt: null,
  isTestActive: false,
  isSubmitting: false,
};

// Reducer
function testReducer(state: TestState, action: TestAction): TestState {
  switch (action.type) {
    case 'SET_STUDENT':
      return { ...state, student: action.payload };

    case 'SET_TEST_CONFIG':
      return {
        ...state,
        testConfig: action.payload,
        overallTimeRemaining: action.payload.total_duration_minutes * 60,
      };

    case 'START_TEST':
      const currentSection = state.testConfig?.sections[state.currentSectionIndex];
      const sectionDurationSeconds = currentSection ? currentSection.duration_minutes * 60 : 60;
      return {
        ...state,
        isTestActive: true,
        testStartedAt: new Date(),
        sectionTimeRemaining: sectionDurationSeconds,
      };

    case 'NEXT_QUESTION':
      return {
        ...state,
        currentQuestionIndex: state.currentQuestionIndex + 1,
      };

    case 'NEXT_SECTION':
      const nextSection = state.testConfig?.sections[state.currentSectionIndex + 1];
      const nextSectionDurationSeconds = nextSection ? nextSection.duration_minutes * 60 : 60;
      return {
        ...state,
        currentSectionIndex: state.currentSectionIndex + 1,
        currentQuestionIndex: 0,
        sectionTimeRemaining: nextSectionDurationSeconds,
      };

    case 'TICK_OVERALL_TIMER':
      const newOverallTime = Math.max(0, state.overallTimeRemaining - 1);
      return {
        ...state,
        overallTimeRemaining: newOverallTime,
        isTestActive: newOverallTime > 0,
      };

    case 'TICK_SECTION_TIMER':
      return {
        ...state,
        sectionTimeRemaining: Math.max(0, state.sectionTimeRemaining - 1),
      };

    case 'RESET_SECTION_TIMER':
      const resetSection = state.testConfig?.sections[state.currentSectionIndex];
      const resetSectionDurationSeconds = resetSection ? resetSection.duration_minutes * 60 : 60;
      return {
        ...state,
        sectionTimeRemaining: resetSectionDurationSeconds,
      };

    case 'SET_SUBMITTING':
      return {
        ...state,
        isSubmitting: action.payload,
      };

    case 'END_TEST':
      return {
        ...state,
        isTestActive: false,
      };

    default:
      return state;
  }
}

// Context
interface TestContextValue {
  state: TestState;
  dispatch: React.Dispatch<TestAction>;
  getCurrentSection: () => Section | null;
  getCurrentQuestion: () => any | null;
  getTotalQuestions: () => number;
  getCurrentQuestionNumber: () => number;
}

const TestContext = createContext<TestContextValue | undefined>(undefined);

// Provider
export function TestProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(testReducer, initialState);

  const getCurrentSection = (): Section | null => {
    if (!state.testConfig) return null;
    return state.testConfig.sections[state.currentSectionIndex] || null;
  };

  const getCurrentQuestion = () => {
    const section = getCurrentSection();
    if (!section) return null;
    return section.questions[state.currentQuestionIndex] || null;
  };

  const getTotalQuestions = (): number => {
    if (!state.testConfig) return 0;
    return state.testConfig.sections.reduce((total, section) => total + section.questions.length, 0);
  };

  const getCurrentQuestionNumber = (): number => {
    if (!state.testConfig) return 0;
    let count = 0;
    for (let i = 0; i < state.currentSectionIndex; i++) {
      count += state.testConfig.sections[i].questions.length;
    }
    return count + state.currentQuestionIndex + 1;
  };

  const value: TestContextValue = {
    state,
    dispatch,
    getCurrentSection,
    getCurrentQuestion,
    getTotalQuestions,
    getCurrentQuestionNumber,
  };

  return <TestContext.Provider value={value}>{children}</TestContext.Provider>;
}

// Hook to use the context
export function useTest() {
  const context = useContext(TestContext);
  if (!context) {
    throw new Error('useTest must be used within a TestProvider');
  }
  return context;
}
